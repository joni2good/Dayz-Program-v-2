import java.util.*;
import java.io.*;
import java.text.*;
public class DayzMain {
    public static void main(String[] args)throws Exception {
        
        String tempObj;
        String tempX = "";
        String tempY = "";
        String tempZ = "";
        double masX;
        double masZ;
        double masY;
        double obj1X;
        double obj1Z;
        double obj1Y;
        double obj2X;
        double obj2Z;
        double obj2Y;
        Scanner sysInLoc = new Scanner(new File("locationIn.txt"));
        PrintStream sysOutLoc = new PrintStream(new FileOutputStream("locationOut.txt"));
        DecimalFormat douFormat = new DecimalFormat("0.000000", new DecimalFormatSymbols(Locale.US));
        
        while(sysInLoc.hasNextLine()) {
            if(sysInLoc.next().equals("objects")) {
                
                sysInLoc.next();
                
                tempObj = removeChar(sysInLoc.next(), 1);
                
                tempX = sysInLoc.next().substring(1);
                masX = Double.parseDouble(tempX);
                
                tempZ = sysInLoc.next();
                masZ = Double.parseDouble(tempZ);
                
                tempY = removeChar(sysInLoc.next(), 2);
                masY = Double.parseDouble(tempY);
                
                for(int i = 0; i < 6; i++) {
                    sysInLoc.next();
                }
                
                tempX = sysInLoc.next().substring(1);
                obj1X = Double.parseDouble(tempX);
                
                tempZ = sysInLoc.next();
                obj1Z = Double.parseDouble(tempZ);
                
                tempY = removeChar(sysInLoc.next(), 2);
                obj1Y = Double.parseDouble(tempY);
                
                for(int i = 0; i < 6; i++) {
                    sysInLoc.next();
                }
                
                tempX = sysInLoc.next().substring(1);
                obj2X = Double.parseDouble(tempX);
                
                tempZ = sysInLoc.next();
                obj2Z = Double.parseDouble(tempZ);
                
                tempY = removeChar(sysInLoc.next(), 2);
                obj2Y = Double.parseDouble(tempY);
                
                sysOutLoc.println("<group name=\"" + tempObj + "\" lootmax=\"2\">\n" +
				                "\t\t<usage name=\"Industrial\" />\n" +
				                "\t\t<usage name=\"Farm\" />\n" +
				                "\t\t<container name=\"lootFloor\" lootmax=\"2\">\n" + 
						                "\t\t\t\t<category name=\"tools\" />\n" +
						                "\t\t\t\t<category name=\"containers\" />\n" +
						                "\t\t\t\t<tag name=\"floor\" />\n" +
						                "\t\t\t\t<point pos=\"" + douFormat.format(obj1X - masX) + " " + douFormat.format(obj1Z - masZ) + " " + douFormat.format(obj1Y - masY) + "\" range=\"0.50\" height=\"1.5\" flags=\"32\" />\n" +
						                "\t\t\t\t<point pos=\"" + douFormat.format(obj2X - masX) + " " + douFormat.format(obj2Z - masZ) + " " + douFormat.format(obj2Y - masY) + "\" range=\"0.50\" height=\"1.5\" flags=\"32\" />\n" +
				                "\t\t</container>\n" +
		                        "</group>\n");
                
            }
        }
        System.out.println("Task done, press e");
    }
    
    public static String removeChar(String str, int del) {
        return str.substring(0, str.length() - del);
    }
    
}

